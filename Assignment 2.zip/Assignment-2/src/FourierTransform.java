/**
 * 
 */

/**
 * @author ujmam
 *
 */
public class FourierTransform {
	public static double[] discreteFT(double[] fdata, int N, boolean fwd) {
		double X[] = new double[2 * N];
		double omega;
		int k;
		int kreal;
		int kimag;
		int n;

		// compute the omega that need in DFT equation for the forward transformation
		omega = 2.0 * Math.PI / N;

		for (k = 0; k < N; k++) {
			kreal = 2 * k;// even part
			kimag = 2 * k + 1;// imaginary part
			// initially both are zero
			X[kreal] = 0.0;
			X[kimag] = 0.0;
			for (n = 0; n < N; ++n) {
				// calculation of real part
				X[kreal] += fdata[2 * n] * Math.cos(omega * n * k) + fdata[2 * n + 1] * Math.sin(omega * n * k);
				// calculation of imaginary part
				X[kimag] += -fdata[2 * n] * Math.sin(omega * n * k) + fdata[2 * n + 1] * Math.cos(omega * n * k);
			}
		}

		for (k = 0; k < N; ++k) {
			X[2 * k] /= N;
			X[2 * k + 1] /= N;
		}

		// return the value of X to TestDFT file
		return X;
	}

}
