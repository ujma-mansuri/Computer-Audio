import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 */

/**
 * @author ujmam
 *
 */
public class DFT {
	public static void main(String args[]) throws IOException {
		// number of samples
		int N = 512;
		// time interval that is here number of data points taken in 2 seconds
		double T = 2.0;
		//sampling time
		double fk;

		// read the data from file , here it's amplitude values from the files
		BufferedReader buffer = new BufferedReader(
				new FileReader("E:\\Semester 3\\Computer Audio\\Assignment\\final data.txt"));
		List<String> lines = new ArrayList<String>();
		String line;
		while ((line = buffer.readLine()) != null) {

			lines.add(line);

		}
		// take the temporary array and copy the data from lines to temp array
		String temp[] = new String[lines.size()];
		temp = lines.toArray(temp);

		double temp1[] = new double[temp.length];
		// for loop upto the length of the temp array
		for (int a = 0; a < temp.length; a++) {

			temp1[a] = Double.parseDouble(temp[a]);
			// convert the dB values to amplitude
			double b = (temp1[a] / 20);
			temp1[a] = Math.pow(10, b);

		}

		// here N is multiplied by 2 because we need 2 parts imaginary and real

		double fdata[] = new double[2 * N];
		for (int i = 0; i < N - 1; ++i) {
			// set all even position
			fdata[2 * i] = temp1[i];

			// set all odd values to zero
			fdata[2 * i + 1] = 0.0;

		}

		// check that if transformation is forward, then perform this
		double X[] = FourierTransform.discreteFT(fdata, N, true);
		for (int k = 0; k < N; ++k) {
			fk = k / T;
			System.out.println("f[" + k + "] = " + fk + "Xreal[" + k + "] = " + X[2 * k] +""+ " Ximaginary[" + k + "] = "
					+ X[2 * k + 1]);
		}
		for (int i = 0; i < N; ++i) {
			fdata[2 * i] = 0.0;
			fdata[2 * i + 1] = 0.0;
			if (i == 4 || i == N - 4) {
				fdata[2 * i] = 0.5;
			}
		}

	}
}
